package controllers;


import com.fasterxml.jackson.databind.JsonNode;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import models.Book;
import models.Dvd;
import models.Reader;
import models.LibraryItem;
import models.Librarymanager;
import org.bson.Document;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class HomeController extends Controller implements Librarymanager {

    //creating arrylists for store values
    List<LibraryItem> usd_mylist;
    List<LibraryItem> usd_mylistNew;
    List<Reader> usd_userListLms;
    List<Reader> usd_userBorrowListLms;
    public static int usd_count_set;
    public static int usd_Dvd_count_set;
    int usdBookCountSet = 0;
    int usdDvdCountSet = 0;

    //config the mongodb connection
    MongoClientURI urlSet = new MongoClientURI(
            "mongodb://uvindu:uvindu123@cluster0-shard-00-00-ggecy.mongodb.net:27017,cluster0-shard-00-01-ggecy.mongodb.net:27017,cluster0-shard-00-02-ggecy.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true");

    MongoClient usd_Lms = new MongoClient(urlSet);

    MongoDatabase lms = usd_Lms.getDatabase("lms");

    //creating collections to store data in database
    MongoCollection<Document> collectionBook = lms.getCollection("book");
    MongoCollection<Document> collectionDvd = lms.getCollection("dvd");
    MongoCollection<Document> collectionUserLms = lms.getCollection("LmsUserList");
    MongoCollection<Document> collectionBorrowLms = lms.getCollection("LmsBorrowList");

    //adding a book details to arraylist
    public Result indexLms() {

        usd_mylist = new ArrayList<>();
        FindIterable<Document> IterateSet = collectionBook.find();

        Iterator itUsd = IterateSet.iterator();

        while (itUsd.hasNext()) {

            Document usd_doc = (Document) itUsd.next();
            int usd_isbn = usd_doc.getInteger("usd_isbn");
            String usd_title = usd_doc.getString("usd_title");
            String usd_sector = usd_doc.getString("usd_sector");
            String usd_publicationDate = usd_doc.getString("usd_publicationDate");
            int usd_noOfPages = usd_doc.getInteger("usd_noOfPages");
            String usd_author = usd_doc.getString("usd_author");
            String usd_publisher = usd_doc.getString("usd_publisher");
            String usd_type = usd_doc.getString("usd_type");

            usd_mylist.add(new Book(usd_isbn, usd_title, usd_sector, usd_publicationDate, usd_noOfPages, usd_author,
                    usd_publisher, usd_type));
            usdBookCountSet = usd_count_set++;

        }
        return ok(Json.toJson((usd_mylist)));

    }


    public Result indexNew() {

        usd_mylistNew = new ArrayList<>();
        FindIterable<Document> IterateSet = collectionDvd.find();

        Iterator itUsd = IterateSet.iterator();

        while (itUsd.hasNext()) {

            Document usd_docNew = (Document) itUsd.next();
            int usd_isbn = usd_docNew.getInteger("usd_isbn");
            String usd_title = usd_docNew.getString("usd_title");
            String usd_sector = usd_docNew.getString("usd_sector");
            String usd_publicationDate = usd_docNew.getString("usd_publicationDate");
            String usd_languages = usd_docNew.getString("usd_languages");
            String usd_subtitles = usd_docNew.getString("usd_subtitles");
            String usd_producer = usd_docNew.getString("usd_producer");
            String usd_actors = usd_docNew.getString("usd_actors");
            String usd_type = usd_docNew.getString("usd_type");

            usd_mylistNew.add(new Dvd(usd_isbn, usd_title, usd_sector, usd_publicationDate, usd_languages,
                    usd_subtitles, usd_producer, usd_actors, usd_type));
            usdDvdCountSet = usd_Dvd_count_set++;
        }
        //returning a jason object
        return ok(Json.toJson((usd_mylistNew)));
    }

    //parsing the arraylist data to database
    public Result usd_addNewBook() {

        JsonNode usd_Jbody = request().body().asJson();
        int usd_isbn = Integer.parseInt(usd_Jbody.get("usd_isbn").asText());
        String usd_title = usd_Jbody.get("usd_title").asText();
        String usd_sector = usd_Jbody.get("usd_sector").asText();
        String usd_publicationDate = usd_Jbody.get("usd_publicationDate").asText();
        String usd_author = usd_Jbody.get("usd_author").asText();
        int usd_noOfPages = Integer.parseInt(usd_Jbody.get("usd_noOfPages").asText());
        String usd_publisher = usd_Jbody.get("usd_publisher").asText();
        String usd_type = "Book";

        Document usd_NewInbook = new Document().append("usd_isbn", usd_isbn).append("usd_title", usd_title)
                .append("usd_sector", usd_sector).append("usd_publicationDate", usd_publicationDate)
                .append("usd_author", usd_author).append("usd_noOfPages", usd_noOfPages)
                .append("usd_publisher", usd_publisher).append("usd_type", usd_type);
        collectionBook.insertOne(usd_NewInbook);
        usdBookCountSet = usd_count_set++;

        return ok("Adding new book successful");

    }

    public Result usd_addDvd() {

        JsonNode usd_Jbody2 = request().body().asJson();

        int usd_isbn = Integer.parseInt(usd_Jbody2.get("usd_isbn").asText());
        String usd_title = usd_Jbody2.get("usd_title").asText();
        String usd_sector = usd_Jbody2.get("usd_sector").asText();
        String usd_publicationDate = usd_Jbody2.get("usd_publicationDate").asText();
        String usd_languages = usd_Jbody2.get("usd_languages").asText();
        String usd_subtitles = usd_Jbody2.get("usd_subtitles").asText();
        String usd_producer = usd_Jbody2.get("usd_producer").asText();
        String usd_actors = usd_Jbody2.get("usd_actors").asText();
        String usd_type = "DVD";

        Document usd_NewInDvd = new Document().append("usd_isbn", usd_isbn).append("usd_title", usd_title)
                .append("usd_sector", usd_sector).append("usd_publicationDate", usd_publicationDate)
                .append("usd_languages", usd_languages).append("usd_subtitles", usd_subtitles)
                .append("usd_producer", usd_producer).append("usd_actors", usd_actors).append("usd_type", usd_type);
        collectionDvd.insertOne(usd_NewInDvd);
        usdDvdCountSet = usd_Dvd_count_set++;

        return ok("Adding new dvd successful");

    }

    public Result DeleteLms(int usd_isbn) {

        //deleting the collection using specific key
        collectionBook.deleteOne(Filters.eq("usd_isbn", usd_isbn));
        collectionDvd.deleteOne(Filters.eq("usd_isbn", usd_isbn));

        return ok("Delete Complete");
    }

    //adding a new user to lms
    public Result newUserLms() {

        usd_userListLms = new ArrayList<>();
        FindIterable<Document> IterateSet = collectionUserLms.find();

        Iterator itUsr = IterateSet.iterator();

        while (itUsr.hasNext()) {

            Document usd_doc = (Document) itUsr.next();
            int usd_id = usd_doc.getInteger("usd_id");
            String usd_fname = usd_doc.getString("usd_fname");
            String usd_tele = usd_doc.getString("usd_tele");
            String usd_eMail = usd_doc.getString("usd_eMail");

            usd_userListLms.add(new Reader(usd_id, usd_fname, usd_tele, usd_eMail));

        }
        return ok(Json.toJson((usd_userListLms)));

    }

    //adding user details to database
    public Result addNewUserLms() {

        JsonNode usd_Jbody3 = request().body().asJson();

        int usd_id = Integer.parseInt(usd_Jbody3.get("usd_id").asText());
        String usd_fname = usd_Jbody3.get("usd_fname").asText();
        String usd_tele = usd_Jbody3.get("usd_tele").asText();
        String usd_eMail = usd_Jbody3.get("usd_eMail").asText();

        Document usd_NewUserLms = new Document().append("usd_id", usd_id).append("usd_fname",usd_fname)
                .append("usd_tele",usd_eMail).append("usd_eMail",usd_eMail);
        collectionUserLms.insertOne(usd_NewUserLms);

        return ok("Adding new User to LMS is successful");

    }

    public Result borrowItemLms() {

        usd_userBorrowListLms = new ArrayList<>();
        FindIterable<Document> IterateSet = collectionBorrowLms.find();

        Iterator itUsr = IterateSet.iterator();

        while (itUsr.hasNext()) {

            Document usd_doc = (Document) itUsr.next();
            int usd_id = usd_doc.getInteger("usd_id");
            String usd_fname = usd_doc.getString("usd_fname");
            String usd_tele = usd_doc.getString("usd_tele");
            String usd_eMail = usd_doc.getString("usd_eMail");
            int lmsisbn = usd_doc.getInteger("lmsisbn");
            String usd_date = usd_doc.getString("usd_date");
            String usd_time = usd_doc.getString("usd_time");

            usd_userBorrowListLms.add(new Reader(usd_id, usd_fname, usd_tele, usd_eMail, lmsisbn, usd_date, usd_time));

        }
        return ok(Json.toJson((usd_userBorrowListLms)));

    }

    public Result borrowItemListLms() {

        JsonNode usd_Jbody4 = request().body().asJson();

        int usd_id = Integer.parseInt(usd_Jbody4.get("usd_id").asText());
        String usd_fname = usd_Jbody4.get("usd_fname").asText();
        String usd_tele = usd_Jbody4.get("usd_tele").asText();
        String usd_eMail = usd_Jbody4.get("usd_eMail").asText();
        int lmsisbn = Integer.parseInt(usd_Jbody4.get("lmsisbn").asText());
        String usd_date = usd_Jbody4.get("usd_date").asText();
        String usd_time = usd_Jbody4.get("usd_time").asText();

        Document usd_NewUserBorrowLms = new Document().append("usd_id", usd_id).append("usd_fname", usd_fname)
                .append("usd_tele", usd_tele).append("usd_eMail", usd_eMail).append("lmsisbn", lmsisbn)
                .append("usd_date", usd_date).append("usd_time", usd_time);

        //removing the borrow items from item list
        collectionBook.deleteOne(Filters.eq("usd_isbn", lmsisbn));
        collectionDvd.deleteOne(Filters.eq("usd_isbn", lmsisbn));
        collectionBorrowLms.insertOne(usd_NewUserBorrowLms);

        return ok("Borrowing item is successful");

    }

    public Result ReturnItemSet() {

        JsonNode usd_Jbody6 = request().body().asJson();

        int usd_id2 = Integer.parseInt(usd_Jbody6.get("usd_id").asText());
        String usd_fname2 = usd_Jbody6.get("usd_fname").asText();
        String usd_tele2 = usd_Jbody6.get("usd_tele").asText();
        String usd_eMail2 = usd_Jbody6.get("usd_eMail").asText();
        int lmsisbn2 = Integer.parseInt(usd_Jbody6.get("lmsisbn").asText());
        String usd_date2 = usd_Jbody6.get("usd_date").asText();
        String usd_time2 = usd_Jbody6.get("usd_time").asText();

        Document usd_NewUserBorrowLms = new Document().append("usd_id", usd_id2).append("usd_fname", usd_fname2)
                .append("usd_tele", usd_tele2).append("usd_eMail", usd_eMail2).append("lmsisbn", lmsisbn2)
                .append("usd_date", usd_date2).append("usd_time", usd_time2);

        //Replacing borrowed data with return values
        collectionBorrowLms.findOneAndReplace(Filters.eq("usd_fname", "Not Borrowed"), usd_NewUserBorrowLms);
        collectionBorrowLms.findOneAndReplace(Filters.eq("usd_id", null), usd_NewUserBorrowLms);
        collectionBorrowLms.findOneAndReplace(Filters.eq("usd_tele", null), usd_NewUserBorrowLms);
        collectionBorrowLms.findOneAndReplace(Filters.eq("usd_eMail", null), usd_NewUserBorrowLms);
        collectionBorrowLms.findOneAndReplace(Filters.eq("lmsisbn", lmsisbn2), usd_NewUserBorrowLms);
        collectionBorrowLms.findOneAndReplace(Filters.eq("usd_date", usd_date2), usd_NewUserBorrowLms);
        collectionBorrowLms.findOneAndReplace(Filters.eq("usd_id", usd_time2), usd_NewUserBorrowLms);

        return ok("Return is Complete");
    }

}