package models;


public class Book extends LibraryItem {

    private int usd_noOfPages;
    private String usd_author;
    private String usd_publisher;
    private String usd_setBookTYpe;

    public Book(int usd_isbn, String usd_title, String usd_sector, String usd_publicationDate,
                int usd_noOfPages, String usd_author, String usd_publisher,String usd_type) {
        super(usd_isbn, usd_title, usd_sector, usd_publicationDate,usd_type);
        this.usd_noOfPages = usd_noOfPages;
        this.usd_author = usd_author;
        this.usd_publisher = usd_publisher;

    }

    public int getUsd_noOfPages() {
        return usd_noOfPages;
    }

    public void setUsd_noOfPages(int usd_noOfPages) {
        this.usd_noOfPages = usd_noOfPages;
    }

    public String getUsd_author() {
        return usd_author;
    }

    public void setUsd_author(String usd_author) {
        this.usd_author = usd_author;
    }

    public String getUsd_publisher() {
        return usd_publisher;
    }

    public void setUsd_publisher(String usd_publisher) {
        this.usd_publisher = usd_publisher;
    }

    public String getUsd_setBookTYpe() {
        return usd_setBookTYpe;
    }

    public void setUsd_setBookTYpe(String usd_setBookTYpe) {
        this.usd_setBookTYpe = usd_setBookTYpe;
    }
}

