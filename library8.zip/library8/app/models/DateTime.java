package models;

public class DateTime {

    int usd_day;
    int usd_month;
    int usd_year;
    int usd_hour;
    int usd_minutes;

    public DateTime(int usd_day, int usd_month, int usd_year, int usd_hour, int usd_minutes) {
        this.usd_day = usd_day;
        this.usd_month = usd_month;
        this.usd_year = usd_year;
        this.usd_hour = usd_hour;
        this.usd_minutes = usd_minutes;
    }

    public int getUsd_day() {
        return usd_day;
    }

    public void setUsd_day(int usd_day) {
        this.usd_day = usd_day;
    }

    public int getUsd_month() {
        return usd_month;
    }

    public void setUsd_month(int usd_month) {
        this.usd_month = usd_month;
    }

    public int getUsd_year() {
        return usd_year;
    }

    public void setUsd_year(int usd_year) {
        this.usd_year = usd_year;
    }

    public int getUsd_hour() {
        return usd_hour;
    }

    public void setUsd_hour(int usd_hour) {
        this.usd_hour = usd_hour;
    }

    public int getUsd_minutes() {
        return usd_minutes;
    }

    public void setUsd_minutes(int usd_minutes) {
        this.usd_minutes = usd_minutes;
    }
}
