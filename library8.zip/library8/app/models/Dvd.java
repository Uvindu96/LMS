package models;

public class Dvd extends LibraryItem {

    private String  usd_languages;
    private String  usd_subtitles;
    private String  usd_producer;
    private String  usd_actors;
    private String usd_setDvdType;

    public Dvd(int usd_isbn, String usd_title, String usd_sector, String usd_publicationDate,
               String usd_languages, String usd_subtitles, String usd_producer, String usd_actors,String usd_type) {
        super(usd_isbn, usd_title, usd_sector, usd_publicationDate,usd_type);
        this.usd_languages = usd_languages;
        this.usd_subtitles = usd_subtitles;
        this.usd_producer = usd_producer;
        this.usd_actors = usd_actors;

}

    public String getUsd_languages() {
        return usd_languages;
    }

    public void setUsd_languages(String usd_languages) {
        this.usd_languages = usd_languages;
    }

    public String getUsd_subtitles() {
        return usd_subtitles;
    }

    public void setUsd_subtitles(String usd_subtitles) {
        this.usd_subtitles = usd_subtitles;
    }

    public String getUsd_producer() {
        return usd_producer;
    }

    public void setUsd_producer(String usd_producer) {
        this.usd_producer = usd_producer;
    }

    public String getUsd_actors() {
        return usd_actors;
    }

    public void setUsd_actors(String usd_actors) {
        this.usd_actors = usd_actors;
    }

}