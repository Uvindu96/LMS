package models;

public abstract class LibraryItem  {

    private int usd_isbn;
    private String usd_title;
    private String usd_sector;
    private String usd_publicationDate;
    private String usd_type;


    public LibraryItem(){

    }

    public LibraryItem(int usd_isbn, String usd_title, String usd_sector, String usd_publicationDate,String usd_type) {
        super();
        this.usd_isbn = usd_isbn;
        this.usd_title = usd_title;
        this.usd_sector = usd_sector;
        this.usd_publicationDate = usd_publicationDate;
        this.usd_type = usd_type;
    }

    public int getUsd_isbn() {
        return usd_isbn;
    }

    public void setUsd_isbn(int usd_isbn) {
        this.usd_isbn = usd_isbn;
    }

    public String getUsd_title() {
        return usd_title;
    }

    public void setUsd_title(String usd_title) {
        this.usd_title = usd_title;
    }

    public String getUsd_sector() {
        return usd_sector;
    }

    public void setUsd_sector(String usd_sector) {
        this.usd_sector = usd_sector;
    }

    public String getUsd_publicationDate() {
        return usd_publicationDate;
    }

    public void setUsd_publicationDate(String usd_publicationDate) {
        this.usd_publicationDate = usd_publicationDate;
    }

    public String getUsd_type() {
        return usd_type;
    }

    public void setUsd_type(String usd_type) {
        this.usd_type = usd_type;
    }
}
