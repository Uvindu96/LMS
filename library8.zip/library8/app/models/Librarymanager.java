package models;

import play.mvc.Result;

public interface Librarymanager {

    public abstract Result usd_addNewBook();
    public abstract Result usd_addDvd();
    public abstract Result DeleteLms(int usd_isbn);
    public abstract Result borrowItemLms();
    public abstract Result borrowItemListLms();
    public abstract Result ReturnItemSet();



}
