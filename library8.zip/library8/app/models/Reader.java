package models;

public class Reader {

    int usd_id;
    String usd_fname;
    String usd_tele;
    String usd_eMail;
    String usd_date;
    String usd_time;
    int lmsisbn;

    public Reader(int usd_id, String usd_fname, String usd_tele, String usd_eMail) {
        this.usd_id = usd_id;
        this.usd_fname = usd_fname;
        this.usd_tele = usd_tele;
        this.usd_eMail = usd_eMail;
    }

    public Reader(int usd_id, String usd_fname, String usd_tele, String usd_eMail,int lmsisbn,String usd_date,String usd_time) {
        this.usd_id = usd_id;
        this.usd_fname = usd_fname;
        this.usd_tele = usd_tele;
        this.usd_eMail = usd_eMail;
        this.lmsisbn =   lmsisbn;
        this.usd_date = usd_date;
        this.usd_time = usd_time;

    }

    public int getUsd_id() {
        return usd_id;
    }

    public void setUsd_id(int usd_id) {
        this.usd_id = usd_id;
    }

    public String getUsd_fname() {
        return usd_fname;
    }

    public void setUsd_fname(String usd_fname) {
        this.usd_fname = usd_fname;
    }

    public String getUsd_tele() {
        return usd_tele;
    }

    public void setUsd_tele(String usd_tele) {
        this.usd_tele = usd_tele;
    }

    public String getUsd_eMail() {
        return usd_eMail;
    }

    public void setUsd_eMail(String usd_eMail) {
        this.usd_eMail = usd_eMail;
    }
}
